#include <stdio.h>
#include <stdlib.h>
#include <queue>
#include <math.h>
#include <unordered_map>
#include <list>
#include "astar.h"
using namespace std;

using Hash = unordered_map<Point, bool, decltype(&point_hash)>;

bool Point::operator==(const Point& point) const
{
	return x == point.x && y == point.y;
}

bool Node::operator< (const Node& node) const
{
	return cost > node.cost;
}
bool Node::operator==(const Node& node) const
{
	return point == node.point;
}

//struct Map
//{
//	int width, height;
//	int *data;
//};
//
//struct Point
//{
//	int x, y;
//	bool operator==(const Point& point) const
//	{
//		return x == point.x && y == point.y;
//	}
//};
//
//size_t point_hash(const Point& point)
//{
//	return point.x ^ point.y + 111;
//}
//
//struct Node
//{
//	Point point;
//	int cost;
//	int step;
//	Node* previous;
//	bool operator< (const Node& node) const
//	{
//		return cost > node.cost;
//	}
//	bool operator==(const Node& node) const
//	{
//		return point == node.point;
//	}
//};

list<Node> nodes;

bool node_less(Node* a, Node* b)
{
	return a->cost > b->cost;
}

using Queue = priority_queue<Node*, vector<Node*>, decltype(&node_less)>;


Map* load_map(const char* filename)
{
	FILE* fp;

	fopen_s(&fp, filename, "r");
	if (!fp)
		return NULL;

	int width = 0, height = 0;
	fscanf_s(fp, "%d %d", &width, &height);
	if (width <= 0 || height <= 0)
		return NULL;

	Map* map = (Map*)malloc(sizeof(Map) + sizeof(int) * width * height);
	map->width = width;
	map->height = height;
	map->data = (int*)(map + 1);

	// ��ȡ����
	width *= height;
	for (int i = 0; i < width; i++)
		fscanf_s(fp, "%d", &map->data[i]);

	return map;
}


void print_map(Map* map)
{
	for (int i = 0; i < map->height; i++)
	{
		for (int j = 0; j < map->width; j++)
		{
			printf("%d ", map->data[i * map->width + j]);
		}
		printf("\n");
	}
}

int manhattan(Point start, Point end)
{
	return abs(start.x - end.x) + abs(start.y - end.y);
}

bool valid(Map* const map, const Point& point)
{
	return point.x < map->width && point.x >= 0 &&
		point.y < map->height && point.y >= 0 &&
		map->data[point.y * map->width + point.x] == 0;
}

Point move_up(const Point& point)
{
	return{ point.x, point.y - 1 };
}

Point move_down(const Point& point)
{
	return{ point.x, point.y + 1 };
}

Point move_left(const Point& point)
{
	return{ point.x-1, point.y};
}

Point move_right(const Point& point)
{
	return{ point.x + 1, point.y };
}

void add(Queue& queue, Point& point, Point& end, int step, Node* previous, Hash& visit)
{
//#ifdef SHOWINFO
//	static int count = 0;
//#endif // SHOWINFO
	auto iter = visit.find(point);
	if (iter == visit.end())
	{
		auto cost = manhattan(point, end) + step;
		nodes.push_back({ point, cost, step, previous });
		queue.push(&nodes.back());
		visit.insert({ point, true });
//#ifdef SHOWINFO
//		printf("%d ���ӽڵ� x = %d, y = %d, cost = %d\n",count++, point.x, point.y, cost);
//#endif // SHOWINFO
	}
}

void expand(Map* map, Node& node, Queue& queue, Point& end, Hash& visit)
{
	static decltype(&move_up) actions[] = { move_up, move_down, move_left, move_right };

	for (auto action : actions)
	{
		auto point = action(node.point);
		if (valid(map, point))
			add(queue, point, end, node.step + 1, &node, visit);
	}
}

Node* AStar(Map* map, Point start, Point end)
{
	Queue queue(node_less);
	Hash visit(128u, point_hash);


	add(queue, start, end, 0, NULL, visit);

	while (!queue.empty())
	{
		Node* node = queue.top();
		queue.pop();

		if (node->point == end)
			return node;

		if (node->point.x == 8 && node->point.y == 2)
			node->point.x = 8;

		expand(map, *node, queue, end, visit);
	}
	return NULL;
}

int main()
{
	Map* map = load_map("data.txt");
	print_map(map);

	Point start = { 0, 4 }, end = { 2, 2 };
	Node* node = AStar(map, start, end);
	if (node == nullptr)
		printf("��·��ͨ\n");
	else
	{
		printf("�ҵ�·��, cost = %d��", node->cost);
		Node* p = node;
		while (p)
		{
			printf("(%d, %d) <-", p->point.x, p->point.y);
			p = p->previous;
		}
	}

	free(map);
	system("pause");
}