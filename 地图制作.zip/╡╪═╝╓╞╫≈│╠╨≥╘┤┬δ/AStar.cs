﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace 地图制作
{
    [System.Runtime.InteropServices.StructLayout(LayoutKind.Sequential)]
    public struct Map
    {
        public int Width;
        public int Height;
        public IntPtr Data;
    }
    [System.Runtime.InteropServices.StructLayout(LayoutKind.Sequential)]
    public struct Point
    {
        public int X;
        public int Y;
    }
     [System.Runtime.InteropServices.StructLayout(LayoutKind.Sequential)]
    public struct Node
    {
         public Point Point;
         public int Cost;
         public int Step;
         public IntPtr Previous;
    }
    public class AS
    {
       [DllImport("AStar.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)]

        public static extern IntPtr AStar(ref Map map, Point start, Point end);


       public static IntPtr StructToIntPtr<T>(T info)
       {
           int size = Marshal.SizeOf(info);
           IntPtr intPtr = Marshal.AllocHGlobal(size);
           Marshal.StructureToPtr(info, intPtr, true);
           return intPtr;
       }

       public static T IntPtrToStruct<T>(IntPtr info)
       {
           return (T)Marshal.PtrToStructure(info, typeof(T));
       }

    }
}
