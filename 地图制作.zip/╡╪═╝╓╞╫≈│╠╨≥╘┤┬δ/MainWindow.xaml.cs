﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace 地图制作
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        int row, column;

        int state = 0;

        Point start, end;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Open_Click(object sender, RoutedEventArgs e)
        {
            // Create OpenFileDialog
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();

            // Set filter for file extension and default file extension
            dlg.DefaultExt = ".txt";
            dlg.Filter = "图片文件|*.*";

            // Display OpenFileDialog by calling ShowDialog method
            Nullable<bool> result = dlg.ShowDialog();

            // Get the selected file name and display in a TextBox
            if (result == true)
            {
                // Open document
                string filename = dlg.FileName;
                try
                {
                    var bitmap = new BitmapImage(new Uri(filename));
                    this.board.Width = bitmap.Width;
                    this.board.Height = bitmap.Height;
                    var img = new ImageBrush(bitmap);
                    this.board.Background = img;
                }catch
                {
                    MessageBox.Show("请选择图像文件");
                }
            }
        }
        // 设置地图宽高
        private void Set_Click(object sender, RoutedEventArgs e)
        {
            SetSizeWindow window = new SetSizeWindow();
            if(window.ShowDialog() == true)
            {
                this.start.X = -1;
                this.end.X = -1;

                this.row = (int)window.Row;
                this.column = (int)window.Column;

                this.board.RowDefinitions.Clear();
                this.board.ColumnDefinitions.Clear();
                this.board.Children.Clear();
                for(var i = 0;i<window.Row;i++)
                {
                    this.board.RowDefinitions.Add(new RowDefinition());
                }
                for (var i = 0; i < window.Column; i++)
                {
                    this.board.ColumnDefinitions.Add(new ColumnDefinition());
                }
                for(var i = 0;i<window.Row;i++)
                {
                    for(var j = 0;j<window.Column;j++)
                    {
                        var rect = new Rectangle();
                        Grid.SetRow(rect, i);
                        Grid.SetColumn(rect, j);
                        this.board.Children.Add(rect);
                        rect.MouseMove += rect_MouseMove;
                        rect.MouseUp += rect_MouseUp;
                        rect.Opacity = 0.4;
                        rect.Fill = Brushes.Transparent;
                        rect.Stroke = Brushes.Black;
                        rect.Tag = 0;
                    }
                }
            }
        }

        private void SetColor(UIElement e, int tag = -1)
        {
            var rect = e as Rectangle;
            if (tag >= 0)
                rect.Tag = tag;
            switch((int)rect.Tag)
            {
                case 0:
                    rect.Fill = Brushes.Transparent;
                    break;
                case 1:
                    rect.Fill = Brushes.Red;
                    break;
                case 2:
                    rect.Fill = Brushes.Blue;
                    rect.Tag = 0;
                    break;
                case 3:
                    rect.Fill = Brushes.Green;
                    rect.Tag = 0;
                    break;
            }
        }

        private void rect_MouseUp(object sender, MouseButtonEventArgs e)
        {
           switch(state)
           {
               case 2:
                   {
                       var rect = sender as Rectangle;
                       if (rect == null)
                           return;
                       if ((int)rect.Tag != 0)
                           return;

                       if(start.X >= 0)
                       {
                           SetColor(this.board.Children[start.Y * column + start.X], 0);
                       }
                       rect.Tag = 2;
                       SetColor(rect);

                       var index = this.board.Children.IndexOf(rect);
                       start.X = index % column;
                       start.Y = index / column;
                       break;
                   }
               case 3:
                   {
                       var rect = sender as Rectangle;
                       if (rect == null)
                           return;
                       if ((int)rect.Tag != 0)
                           return;

                       if (end.X >= 0)
                       {
                           SetColor(this.board.Children[end.Y * column + end.X], 0);
                       }
                       rect.Tag = 3;
                       SetColor(rect);

                       var index = this.board.Children.IndexOf(rect);
                       end.X = index % column;
                       end.Y = index / column;
                       break;
                   }
           }
            
        }

        private void rect_MouseMove(object sender, MouseEventArgs e)
        {
            if (state != 1)
                return;
            if(e.LeftButton == MouseButtonState.Pressed)
            {
                var rect =  ((Rectangle)sender);
                rect.Fill = Brushes.Red;
               rect.Tag = 1;
            }
            else if(e.RightButton == MouseButtonState.Pressed)
            {
                var rect = ((Rectangle)sender);
                rect.Fill = Brushes.Transparent;
                rect.Tag = 0;
            }
        }

        private int[,] GetMap()
        {
            int[,] map = new int[row, column];
            for (var i = 0; i < row; i++)
            {
                for (var j = 0; j < column; j++)
                {
                    map[i, j] = Convert.ToInt32(((Rectangle)this.board.Children[i * column + j]).Tag);
                }
            }
            return map;
        }

        private int[] GetMapData()
        {
            int[] map = new int[row * column];
            for (var i = 0; i < row; i++)
            {
                for (var j = 0; j < column; j++)
                {
                    map[i * column + j] = Convert.ToInt32(((Rectangle)this.board.Children[i * column + j]).Tag);
                }
            }
            return map;
        }

        private void Export_Click(object sender, RoutedEventArgs e)
        {
            FileStream file = new FileStream("data.txt", FileMode.Create, FileAccess.Write);
            StreamWriter sw = new StreamWriter(file);
            sw.Write(row);
            sw.Write(' ');
            sw.WriteLine(column);

            var map = GetMap();
            for(var i = 0;i<row;i++)
            {
                for(var j = 0;j<column;j++)
                {
                    sw.Write(map[i, j]);
                    sw.Write(' ');
                }
                sw.WriteLine();
            }
            sw.Close();
            file.Close();
            MessageBox.Show("导出成功！");
        }

        private void Test_Click(object sender, RoutedEventArgs e)
        {
            if (start.X < 0 || end.X < 0)
            {
                MessageBox.Show("请先标记起点和终点");
                return;
            }

            Map map = new Map();
            map.Width = row;
            map.Height = column;
            var mapData = GetMapData();
            map.Data = 
                System.Runtime.InteropServices.Marshal.UnsafeAddrOfPinnedArrayElement(mapData, 0);

            var pNode = AS.AStar(ref map, start, end);

            if(pNode == IntPtr.Zero)
            {
                MessageBox.Show("找不到路径");
                return;
            }

            MarkPath(pNode);
        }

        private void MarkPath(IntPtr pNode)
        {
            Node node;
            do
            {
                node = AS.IntPtrToStruct<Node>(pNode);
                var rect = (Rectangle)this.board.Children[node.Point.Y * column + node.Point.X];

                rect.Fill = Brushes.Yellow;

                pNode = node.Previous;
            } while (pNode != IntPtr.Zero);
        }

        private void MarkObstacleClick(object sender, RoutedEventArgs e)
        {
            state = 1;
        }

        private void MarkStartClick(object sender, RoutedEventArgs e)
        {
            state = 2;
        }

        private void MarkEndClick(object sender, RoutedEventArgs e)
        {
            state = 3;
        }
    }
}
