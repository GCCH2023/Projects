#include "RegexConcat.h"
using namespace gcl;

RegexConcat::RegexConcat(RegexObject* regex1, RegexObject* regex2)
{
	this->regex1 = regex1;
	this->regex2 = regex2;
}


RegexConcat::~RegexConcat()
{
	delete regex1;
	delete regex2;
}

const char* gcl::RegexConcat::Match(const char* string)
{
	const char* result = regex1->Match(string);

	if (!result)
		return nullptr;

	return regex2->Match(result);
}
