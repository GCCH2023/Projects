#include "RegexKleeneClosure.h"
using namespace gcl;

RegexKleeneClosure::RegexKleeneClosure(RegexObject* regex)
{
	this->regex = regex;
}


RegexKleeneClosure::~RegexKleeneClosure()
{
	delete regex;
}

const char* gcl::RegexKleeneClosure::Match(const char* string)
{
	const char* result = string;
	do{
		string = result;
		result = regex->Match(string);
	} while (result != nullptr);
	// ���ص�����һ��ƥ��Ľ��
	return string;
}
