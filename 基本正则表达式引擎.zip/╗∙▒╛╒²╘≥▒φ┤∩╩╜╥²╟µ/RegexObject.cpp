#include "RegexObject.h"
using namespace gcl;

RegexObject::RegexObject()
{
}


RegexObject::~RegexObject()
{
}
