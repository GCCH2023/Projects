#include "RegexChar.h"
using namespace gcl;

RegexChar::RegexChar(char ch) :c(ch)
{
}


RegexChar::~RegexChar()
{
}

const char* gcl::RegexChar::Match(const char* string)
{
	return *string == c ? string + 1 : NULL;
}
