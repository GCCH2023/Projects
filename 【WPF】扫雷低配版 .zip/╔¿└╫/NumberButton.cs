﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace 扫雷
{
    class NumberButton : Button
    {
        // 值
        public int Value { get; set; }
        // 坐标
        public int Y { get; set; }
        public int X { get; set; }
        // 当前状态 0 正常状态 ，1 标记为地雷，2 未知（？）
        private int state = 0;
        public int State
        {
            get { return state; }
            set
            {
                if (value > 2)
                    value = 0;
                else if (value < 0)
                    value = 2;
                // 禁用/启用点击事件
                if (state == 1 && value != 1)
                    this.Click += btn_Click;
                else if (state != 1 && value == 1)
                    this.Click -= btn_Click;
                state = value;
                ChangeState();
            }
        }
        /// <summary>
        /// 该表按钮的显示
        /// </summary>
        private void ChangeState()
        {
            switch (state)
            {
                case -1: 
                    this.IsEnabled = false;
                    this.Content = this.Value.ToString();
                    break;
                case 0:
                    this.Content = "";
                    break;
                case 1:
                    this.Content = "♂";
                    break;
                case 2:
                    this.Content = "？";
                    break;
            }
        }
        private System.Windows.RoutedEventHandler btn_Click = null;
        /// <summary>
        /// 传入点击事件处理函数
        /// </summary>
        /// <param name="onclick"></param>
        public NumberButton(System.Windows.RoutedEventHandler onclick):base()
        {
            this.State = 0;
            this.btn_Click = onclick;
            this.Click += onclick;
            this.MouseRightButtonUp += NumberButton_MouseRightButtonUp;
        }
        /// <summary>
        /// 右键单击时改变按钮状态
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void NumberButton_MouseRightButtonUp(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            this.State++;
        }
    }
}
