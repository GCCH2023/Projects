﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace 扫雷
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        private int row = 16;        // 行数
        private int col = 30;        // 列数
        private int n_mine = 99;     // 雷数
        private int n_land = 0;     // 空地数，判断 输赢
        // 是否开启调试模式，开启则生成雷区时显示各方格数值
        private bool debug_mode = false;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            CreateBoard();
            Reset();
        }
        /// <summary>
        /// 创建雷区
        /// </summary>
        private void CreateBoard()
        {
            this.board.RowDefinitions.Clear();
            this.board.ColumnDefinitions.Clear();
            for (int i = 0; i < row; i++)
                this.board.RowDefinitions.Add(new RowDefinition());
            for (int i = 0; i < col; i++)
                this.board.ColumnDefinitions.Add(new ColumnDefinition());
        }
        /// <summary>
        /// 重置雷区
        /// </summary>
        private void Reset()
        {
            this.board.Children.Clear();
            var board = this.CreateBoardData(row, col, n_mine);
            this.mine_count.Text = this.n_mine.ToString();
            this.land_count.Text = this.n_land.ToString();
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < col; j++)
                {
                    NumberButton btn = new NumberButton(btn_Click);
                    btn.Y = i;
                    btn.X = j;
                    btn.Value = board[i + 1, j + 1];
                    if(this.debug_mode)
                        btn.Content = board[i + 1, j + 1].ToString();
                    //if (board[i + 1, j + 1] == -1)
                    //    btn.Background = Brushes.Red;
                    Grid.SetRow(btn, i);
                    Grid.SetColumn(btn, j);
                    this.board.Children.Add(btn);
                }
            }
        }
        /// <summary>
        /// 创建雷区
        /// </summary>
        /// <param name="row">雷区行数</param>
        /// <param name="col">雷区列数</param>
        /// <param name="n">地雷数</param>
        /// <returns>代表雷区的二维数组，数组元素代表格子类型，0 - 8代表周围雷的个数，-1代表雷</returns>
        private int[,] CreateBoardData(int row, int col, int n)
        {
            // 重置
            n_land = row * col - n_mine;

            var mines = CreateMines(row, col, n);
            // 为了便于计算，雷区四周多出一格
            int[,] board = new int[row + 2, col + 2];
            foreach (var i in mines)
            {
                board[i / col + 1, i % col + 1] = -1;       // 设置地雷
            }
            // 计算格子周围的雷数
            for (int i = 1; i <= row; i++)
            {
                for (int j = 1; j <= col; j++)
                {
                    board[i, j] = CountMines(ref board, i, j);
                }
            }
            return board;
        }
        /// <summary>
        /// 计算(i, j)格周围的雷数
        /// </summary>
        /// <param name="board"></param>
        /// <param name="i"></param>
        /// <param name="j"></param>
        /// <returns></returns>
        private int CountMines(ref int[,] board, int i, int j)
        {
            // 此格本身是雷则不计算
            if (board[i, j] == -1) return -1;
            // 从左往右，从上往下计算周围8格的雷数
            int[, ,] offset = new int[, ,]{
                {{-1}, {-1}},{{1}, {0}},{{1},{0}},
                {{-2}, {1}},                {{2},{0}},
                {{-2}, {1}},{{1}, {0}},{{1},{0}}
            };
            int count = 0;
            for (int k = 0; k < 8; k++)
            {
                i += offset[k, 0, 0];
                j += offset[k, 1, 0];
                count += board[i, j] == -1 ? 1 : 0;
            }
            return count;
        }
        /// <summary>
        /// 获取地雷的一维位置
        /// </summary>
        /// <param name="row">行数</param>
        /// <param name="col">列数</param>
        /// <param name="n">雷数</param>
        /// <returns>返回n个雷的位置</returns>
        private int[] CreateMines(int row, int col, int n)
        {
            var board = new int[row * col];
            for (int i = 0; i < row * col; i++)
            {
                board[i] = i;
            }
            Random r = new Random();
            for (int i = 0; i < row * col;i++)
            {
                int k = r.Next(row * col);
                int t = board[i];
                board[i] = board[k];
                board[k] = t;
            }
            var mines = new int[n];
            for (int i = 0; i < n; i++)
                mines[i] = board[i];
            return mines;
        }
        /// <summary>
        /// 点击按钮
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_Click(object sender, RoutedEventArgs e)
        {
            var btn = sender as NumberButton;
            var brushes = new Brush[]{
                Brushes.White,
                Brushes.Red,Brushes.Orange,Brushes.Yellow,Brushes.LightGreen,
                Brushes.Green,Brushes.AliceBlue, Brushes.Blue,Brushes.Purple,Brushes.Pink
            };
            if (btn != null)
            {
                if (btn.Value == -1)
                {
                    ShowButton(btn); 
                    ShowMines();
                    MessageBox.Show("GAME OVER！", "扫雷");
                }
                else
                {
                    if (btn.Value == 0)
                        Expand(btn);
                    else
                        ShowButton(btn); 
                    if (n_land == 0)
                        Win();
                }
                //if (btn.Value >= 0)
                //    btn.Foreground = brushes[btn.Value];
                btn.IsEnabled = false;

                this.mine_count.Text = this.n_mine.ToString();
                this.land_count.Text = this.n_land.ToString();
            }
        }
        /// <summary>
        /// 点开按钮，显示按钮的值
        /// </summary>
        /// <param name="btn"></param>
        private void ShowButton(NumberButton btn)
        {
            if (btn.IsEnabled == false)         // 已经点开了
                return;
            switch (btn.Value)
            {
                case 0: btn.Content = ""; break;
                case -1: btn.Content = "*"; break;
                default:
                    btn.Content = btn.Value.ToString();
                    break;
            }
            btn.IsEnabled = false;

            n_land--;       // 空格被点开了
        }
        private NumberButton GetButton(int x, int y)
        {
            if (x >= col || x < 0 || y >= row || y < 0) return null;
            var n = y * col + x;
            if (n < 0 || n >= this.board.Children.Count)
                return null;
            return (NumberButton)this.board.Children[n];
        }
        // 扩展值为0的格子
        private void Expand(NumberButton btn)
        {
            Queue<NumberButton> queue = new Queue<NumberButton>();
            Dictionary<NumberButton, bool> dic = new Dictionary<NumberButton, bool>();
            int[, ,] offset = new int[,,]{       // 左上右下的偏移量
                {{-1},{0}},{{0},{-1}},
                {{1},{0}},{{0},{1}}
            };
            // 广度优先遍历扩展
            queue.Enqueue(btn);
            dic.Add(btn, true);
            ShowButton(btn);
            while (queue.Count != 0)
            {
                btn = queue.Dequeue();
                // 探索四周的格子
                for (int i = 0; i < 4; i++)
                {
                    NumberButton node = GetButton(btn.X + offset[i, 0, 0], btn.Y + offset[i, 1, 0]);
                    // 没有点开且没有访问过的节点就加入队列
                    if (node != null)
                    {
                        if (!dic.ContainsKey(node) && node.Value == 0)      // 没访问过的0节点
                        {
                            queue.Enqueue(node);            // 加入队列
                            dic[node] = true;       // 标记已访问
                            ShowButton(node);
                        }
                        else if (node.Value > 0)        // 边缘节点
                        {
                            ShowButton(node);
                        }
                    }
                }
            }
        }
        /// <summary>
        /// 游戏赢了
        /// </summary>
        private void Win()
        {
            this.board.IsEnabled = false;
            MessageBox.Show("YOU WIN!");
        }
        /// <summary>
        /// 显示所有的格子
        /// </summary>
        private void ShowMines()
        {
            foreach (NumberButton btn in this.board.Children)
            {
                ShowButton(btn);
            }
        }
        /// <summary>
        /// 判断是否结束
        /// </summary>
        /// <returns></returns>
        private bool IsWin()
        {
            // 扫雷结束的条件是点开所有不是雷的格子
            foreach (NumberButton btn in this.board.Children)
            {
                if (btn.Value != -1 && btn.IsEnabled)       // 有一个不是雷的按钮没有被点开
                    return false;
            }
            return true;
        }
        /// <summary>
        /// 操作说明
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("左键点开格子，右键标记格子类型。");
        }
        /// <summary>
        /// 重新开始
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Restart_Click(object sender, RoutedEventArgs e)
        {
            Reset();
        }
        /// <summary>
        /// 初级难度 9 * 9 ~ 10
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Primary_Click(object sender, RoutedEventArgs e)
        {
            row = 9;
            col = 9;
            n_mine = 10;
            CreateBoard();
            Reset();
        }
        /// <summary>
        /// 中级难度 16 * 16 ~ 40
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Middle_Click(object sender, RoutedEventArgs e)
        {
            row = 16;
            col = 16;
            n_mine = 40;
            CreateBoard();
            Reset();
        }
        /// <summary>
        /// 高级 16 * 30 ~ 99
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Senior_Click(object sender, RoutedEventArgs e)
        {
            row = 16;
            col = 30;
            n_mine = 99;
            CreateBoard();
            Reset();
        }
        /// <summary>
        /// 调试模式，即生成雷区时显示方格的数字
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Debug_Click(object sender, RoutedEventArgs e)
        {
            this.debug_mode = !this.debug_mode;
        }
    }
}
